"""
Cover Letter Generator Application
""" 