"""
Business logic services for the Cover Letter Generator
""" 