"""
API routes for the Cover Letter Generator
""" 