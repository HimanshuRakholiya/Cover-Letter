"""
Utility functions and scripts for development and testing
""" 