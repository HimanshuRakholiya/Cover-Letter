"""
Core functionality for the Cover Letter Generator
""" 